package net.ukr.vlsv.hw10.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import net.ukr.vlsv.hw10.R

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }
}


//xmlns:tools="http://schemas.android.com/tools"
//tools:node="replace"
//tools:replace="android:appComponentFactory"
