package net.ukr.vlsv.hw10.activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import net.ukr.vlsv.hw10.R

class UserItem : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_item)
    }
}
