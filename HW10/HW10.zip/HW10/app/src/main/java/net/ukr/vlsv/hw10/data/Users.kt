package net.ukr.vlsv.hw10.data

class Users (
    val Name: String,
    val FullName: String
)